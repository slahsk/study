package com.portal.common.excel;

import java.lang.reflect.Field;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.Comment;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellUtil;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.util.ReflectionUtils;

import com.portal.common.excel.dto.ExcelError;
import com.portal.common.excel.dto.ExcelGroupHeaderVO;
import com.portal.common.excel.dto.ExcelHeaderVO;
import com.portal.common.excel.dto.ExcelResponseVO;
import com.portal.common.file.dto.FileResultVO;
import com.portal.common.file.dto.FileUploadErrVO;
import com.portal.common.file.service.FileService;
import com.portal.common.security.login.CustomUserDetails;

@Component
public class ExcelSupport {
	private final static Logger log = Logger.getLogger(ExcelSupport.class);
	
	public static String EXCEL_HEADER = "header";
	public static String EXCEL_DATA = "data";
	public static String EXCEL_FILE_NAME = "fileName";
	public static String EXCEL_SHHEET = "sheet";
	public static String EXCEL_GROUP = "group";
	public static String EXCEL_DATA_LIST = "dataList";
	
	@Autowired
	private FileService fileService;
	
	private CellStyle bodystyle;
	
	
	/**
	 * Description : 헤더 그룹정보가 있는 엑셀 생성
	 * 
	 * @param workbook
	 * @param info
	 */
	public void create(Workbook workbook, ExcelGroupHead info){
		log.info("Excel 생성  시작");
		
		
        Sheet sheet = workbook.createSheet(info.getSheetName());
    	int nextRow = setGroupHeader(workbook, sheet, info.getGroupHeader(), false);
		
        // create header row
     
    	nextRow =  setHeader(workbook, sheet ,info.getHeader(), nextRow,false);
        // Create data cells
        setData(workbook,sheet ,info, nextRow,false);
        
        
        log.info("Excel 생성  완료");
	}
	
	


	/**
	 * Description : 기본적으로 사용 되는 엑셀 생성
	 * 
	 * @param workbook
	 * @param info
	 */
	public void create(Workbook workbook, ExcelDefaultInfo info){
		log.info("Excel 생성  시작");
		
		
        Sheet sheet = workbook.createSheet(info.getSheetName());

        // create header row
     
        
        int nextRow = setHeader(workbook, sheet ,info.getHeader());
        // Create data cells
        setData(workbook, sheet ,info , nextRow,false);
        
        
        log.info("Excel 생성  완료");
	}
	
	
	/**
	 * Description : 에러 발생시 엑셀 생성
	 * 
	 * @param workbook
	 * @param info
	 */
	public <T>void create(Workbook workbook, ExcelErrorInfo<T> info){
		log.info("ERROJR Excel 생성  시작");
		
		
        Sheet sheet = workbook.createSheet(info.getSheetName());
        // create header row
        int nextRow = setGroupHeader(workbook, sheet, info.getGroupHeader() , true);
        
        nextRow =  setHeader(workbook, sheet ,info.getHeader(), nextRow,true);
        
        setData(workbook, sheet ,info , nextRow,true);
        
        log.info("ERROR Excel 생성  완료");
	}

	/**
	 * Description : 
	 * 
	 * @param workbook
	 * @param sheet
	 * @param info : 엑셀 파일 정보
	 * @param nextRow : 헤더부분 생성후  다음 Row Index
	 */
	private void setData(Workbook workbook,Sheet sheet,ExcelDefaultInfo info, int nextRow, boolean error) {
		//cell style 설정
		Cell cell;
		DataFormat dataFormat = workbook.createDataFormat();

		bodystyle = workbook.createCellStyle();
		bodystyle.setDataFormat(dataFormat.getFormat("#,##0"));

		log.info("Excel Data 생성");
        log.info("Excel Data 개수 : "+info.getData().size());
		int rowCount = nextRow;
        for (Object data : info.getData()){
            Row row = sheet.createRow(rowCount++);
            
            Class<?> clazz=  data.getClass();
            
            
            int dataCellCount = 0;
            Object cellData = data;
            
            if(error){
            	ExcelError<?> excelError = ExcelError.class.cast(data) ;
            	List<String> keyList = new ArrayList<String>(excelError.getErrorField().keySet());
            	List<String> valueList = new ArrayList<String>(excelError.getErrorField().values());
            	
            	row.createCell(0).setCellValue(String.join(", ", keyList));
            	row.createCell(1).setCellValue("["+excelError.getExcepErrorType()+"]"+String.join(", ",valueList));
            	clazz = excelError.getData().getClass();
            	cellData = excelError.getData();
            	dataCellCount = 2;
            }
            
            
            for(ExcelHeaderVO excelHeader : info.getHeader()){
            	 Object val = getCellData(cellData, clazz, excelHeader);
            	 
            	 if(val instanceof Integer){
            		 cell = row.createCell(dataCellCount);
            		 cell.setCellStyle(bodystyle);
                	 cell.setCellValue((Integer) val);
            	 }else{
            		 cell = row.createCell(dataCellCount);
            		 cell.setCellValue(String.valueOf(val));
            	 }
            	
            	 dataCellCount++;
            }
        }
        
        
        log.info("Excel Data 완료");
	}




	private Object getCellData(Object data, Class<?> clazz, ExcelHeaderVO excelHeader) {
		
		Field field =  ReflectionUtils.findField(clazz, excelHeader.getProperty());
		Object val = null;
		
		 if(Objects.isNull(field)){
			 log.info("속성을 찾을수 없습니다 : "+ clazz.getName());
			 log.info("속성을 찾을수 없습니다 : "+ excelHeader.toString());
			 val = "";
		 }else{
			 field.setAccessible(true);
			 
			 val =  ReflectionUtils.getField(field,data);
			 
			 field.setAccessible(false);
			 if(Objects.isNull(val)){
				 val = "";
			 }
		 }
		 
		return val;
	}
	
	/**
	 * Description :엑셀 파일에 첫번째에 에러 필드 명 두번째에 에러 내용을 추가 하고 데이터를 입력한다.
	 * 
	 * @param sheet : poi sheet 객체
	 * @param info : 엑셀 에러 정보를 가지고 있는 객체
	 */
//	private <T>void setDataWithError(Workbook wb, Sheet sheet,ExcelErrorInfo<T> info, int nextRow) {
//        log.info("Excel Data 생성");
//        log.info("Excel Data 개수 : "+info.getData().size());
//        
//        
//		int rowCount = nextRow;
//        for (ExcelError<T> data : info.getData()){
//            Row row = sheet.createRow(rowCount++);
//            
//            Class<?> clazz=  data.getData().getClass();
//            
//            
//            //error 필드 및 메세지 추가
//            List<String> keyList = new ArrayList<String>(data.getErrorField().keySet());
//            List<String> valueList = new ArrayList<String>(data.getErrorField().values());
//            
//            row.createCell(0).setCellValue(String.join(", ", keyList));
//            row.createCell(1).setCellValue("["+data.getExcepErrorType()+"]"+String.join(", ",valueList));
//            
//            int dataCellCount = 2;
//            for(ExcelHeaderVO excelHeader : info.getHeader()){
//            	Object val = getCellData(data, clazz, excelHeader);
//        		row.createCell(dataCellCount).setCellValue(String.valueOf(val) );
//            	
//        		dataCellCount++;
//            }
//            
//            
//        }
//        log.info("Excel Data 완료");
//	}
	
	private void setHeaderStyle(CellStyle style) {
		style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.index); 
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);     //색 패		
		style.setBorderBottom(CellStyle.BORDER_THIN);
		style.setBorderTop(CellStyle.BORDER_THIN);
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
	}
	
	private int setHeader(Workbook wb,Sheet sheet,List<ExcelHeaderVO> headerList) {
		return setHeader(wb, sheet, headerList,0,false);
	}
	

	private int setHeader(Workbook wb,Sheet sheet,List<ExcelHeaderVO> headerList, int nextRow, boolean error) {
		log.info("Excel Header 생성");
		
		//헤더 스타일 생성

		
		int rowCount = nextRow;
		Row row = sheet.createRow(rowCount);
        
		int headerCellCount = 0;
		
		
		if(error){
			Cell errorField = row.createCell(0);
			errorField.setCellValue("FIELD");
			Cell errorMessage = row.createCell(1);
			errorMessage.setCellValue("ERROR");
			
    		
			CellStyle style =  wb.createCellStyle();
    		setHeaderStyle(style);
    		style.setFillForegroundColor(IndexedColors.RED.index);
    		
    		
    		Font font = wb.createFont();
    		font.setColor(IndexedColors.WHITE.index);
    		style.setFont(font);
    		
    		errorField.setCellStyle(style);   
    		errorMessage.setCellStyle(style);
			headerCellCount = 2;
		}
        
        
        
        for(ExcelHeaderVO excelHeader : headerList){
    		CellStyle style =  wb.createCellStyle();
    		setHeaderStyle(style);
        	
        	Cell cell = row.createCell(headerCellCount);
        	cell.setCellValue(excelHeader.getHeader());
        	
        	if(StringUtils.isNoneEmpty(excelHeader.getComment())){
        		CreationHelper factory = wb.getCreationHelper();
        		Drawing drawing = sheet.createDrawingPatriarch();
        		ClientAnchor anchor = factory.createClientAnchor();
        		anchor.setCol1(cell.getColumnIndex());
        		anchor.setCol2(cell.getColumnIndex()+1);
        		anchor.setRow1(row.getRowNum());
        		anchor.setRow2(row.getRowNum()+3);
        		Comment comment = drawing.createCellComment(anchor);
        		RichTextString str = factory.createRichTextString(excelHeader.getComment());
        		comment.setString(str);
        		comment.setAuthor("TIAMS");
        		cell.setCellComment(comment);
        	}
            
        	    
        	    
          	if(Objects.nonNull(excelHeader.getFontColor())){
        		Font font = wb.createFont();
        		font.setColor(excelHeader.getFontColor().index);
        		style.setFont(font);
        	}
          	
        	cell.setCellStyle(style);      
        	
           	if(excelHeader.getWidth() != 0){
           		sheet.setColumnWidth(headerCellCount, excelHeader.getWidth());
        	}
           	
           	
        	headerCellCount++;
        }
        log.info("Excel Header 완료");
        
        return ++rowCount;
	}




	
	/**
	 * Description : 에러 발생시 생서되는 헤더 에러 필드 추가
	 * 
	 * @param sheet
	 * @param headerList
	 * @return
	 */
//	private int setHeaderWithError(Workbook wb, Sheet sheet,List<ExcelHeaderVO> headerList) {
//		log.info("Excel Header 생성");
//		
//		int nextRow = 0;
//		Row header = sheet.createRow(nextRow);
//		
//		header.createCell(0).setCellValue("FIELD");
//		header.createCell(1).setCellValue("ERROR");
//		
//        int headerCellCount = 2;
//        for(ExcelHeaderVO excelHeader : headerList){
//        	header.createCell(headerCellCount).setCellValue(excelHeader.getHeader());
//        	headerCellCount++;
//        }
//        log.info("Excel Header 완료");
//        
//        return ++nextRow;
//	}

	private int setGroupHeader(Workbook workbook, Sheet sheet, List<ExcelGroupHeaderVO> groupHeader, boolean error) {
		
		List<ExcelGroupHeaderVO> groupList = new ArrayList<>(groupHeader);
		
		CellStyle style =  workbook.createCellStyle();
		setHeaderStyle(style);
		
		if(error){
			int rastRow = 0;
			
			for(ExcelGroupHeaderVO group : groupHeader){
				CellRangeAddress cra = group.getCellRangeAddress();
				cra.setFirstColumn(cra.getFirstColumn() + 2);
				cra.setLastColumn(cra.getLastColumn() + 2);
				
				if(rastRow < cra.getLastRow()){
					rastRow = cra.getLastRow();
				}
			}
			if(groupHeader.size() > 0 ){
				groupList.add(new ExcelGroupHeaderVO(new CellRangeAddress(0,rastRow,0,1),"ERROR"));
			}
		}
		
		
		int nextRow = 0;
        
        for(ExcelGroupHeaderVO group : groupList){

        	
        	//각각의 ROW 의 COLUMN에 헤더 스타일 적용시키기
        	for(int i = group.getCellRangeAddress().getFirstColumn(); i <= group.getCellRangeAddress().getLastColumn() ; i++){
        		
        		for(int j = group.getCellRangeAddress().getFirstRow(); j <= group.getCellRangeAddress().getLastRow(); j++){
        			
        			Row currentRow = sheet.getRow(j);
        			
        			if(Objects.isNull(currentRow)){
        				currentRow = sheet.createRow(j);
        			}
        			
        			if(Objects.isNull(currentRow.getCell(i))){
        				Cell cell = currentRow.createCell(i);
        				cell.setCellStyle(style);
        			}
        		}//end for
        		
        		
        	}//end for
        	
        	
        	//헤더 머지 및  타이틀 입력
        	Row currentRow = sheet.getRow(group.getCellRangeAddress().getFirstRow());
        	Cell cell = currentRow.getCell(group.getCellRangeAddress().getFirstColumn());
        	cell.setCellValue(group.getTitleText());
        	
        	
        	//first 하고 last 같으면  타이틀만 입력 처리
        	if(group.getCellRangeAddress().getFirstColumn() != group.getCellRangeAddress().getLastColumn()){
        		sheet.addMergedRegion(group.getCellRangeAddress());
        		
        	}
        	
        	//글자 가운데 정렬
        	CellUtil.setAlignment(cell, workbook, CellStyle.ALIGN_CENTER);
        	
        	
        	//가장 마지막 rowIndex 구하기
        	if(nextRow < group.getCellRangeAddress().getLastRow()){
        		nextRow = group.getCellRangeAddress().getLastRow();	
        	}
        	
        }
        
        //그룹생성후 다음 row 이동
		if(groupList.size() > 0 ){
			nextRow++;
		}
        
        
		return nextRow;
	}
	
	/**
	 * Description : 
	 * 
	 * @param response : 엑셀 파싱 및 디비 데이터 비교 시 발생하는 에러 정보를 가지고 있는 객체
	 * @param function : 클라이언트 에서 기능을 정의하여 사용
	 * @return
	 */
	public <T>ExcelResponseVO<T> getExcelResponse(ExcelResponseVO<T> response,Function<ExcelResponseVO<T>,Integer> function){
		log.info("Excel 공통 Response 생성");
		
		
		int cnt = function.apply(response);
		
		
		if(response.getErrorList().size() > 0){
			//Excel 파일 만들어서 파일 저장
			Assert.hasText(response.getFileName(),"파일 이름이 없습니다.");
			Assert.notNull(response.getHeader(),"Excel 헤더 정보가 없습니다.");
			Assert.hasText(response.getTaskItemEventCd(),"코드가 없습니다.");
			
			log.info("Error 파일생성");
			ExcelErrorInfo<T> info = new ExcelErrorInfo<T>(){

				@Override
				public String getFileName() {
					CustomUserDetails details = (CustomUserDetails)SecurityContextHolder.getContext().getAuthentication().getDetails();
					StringBuilder sb = new StringBuilder(response.getFileName());
					sb.append("_");
					sb.append(details.getUsername());
					sb.append("_");
					sb.append("전체_"+response.getTotalCount());
					sb.append("_");
					sb.append("ERROR_"+response.getErrorList().size());
					sb.append(".xlsx");
					return sb.toString();
				}

				@Override
				public String getSheetName() {
					return "ERROR";
				}

				@Override
				public List<ExcelError<T>> getData() {
					
					return response.getErrorList();
				}

				@Override
				public List<ExcelHeaderVO> getHeader() {
					return response.getHeader();
				}

				@Override
				public List<ExcelGroupHeaderVO> getGroupHeader() {
					return response.getGroupHeader();
				}
				
				
			};
			
			
			log.info("Excel 파일 생성");
			Path path = Paths.get(info.getFileName());
			Workbook wb = new XSSFWorkbook();
			
			create(wb,info);
			
			
			log.info("Excel 파일 생성 완료");
			
			log.info("Excel 파일 정보입력");
			FileResultVO fileResult = fileService.insertFile(path, wb);
			log.info("Excel 파일 정보입력 완료");
			
			log.info("Error 정보입력");
			
			FileUploadErrVO err = new FileUploadErrVO();
			err.setAttachSeq(fileResult.getAttachSeq());
			
			err.setActvTaskCd(response.getActvTaskCd());
			err.setActvItemCd(response.getActvItemCd());
			err.setActvEventCd(response.getActvEventCd());
			
			err.setErrTitle(info.getFileName());
			err.setInsUserId(err.getSessionId());
			err.setUpdUserId(err.getSessionId());
			
			fileService.insertFileUploadErr(err);
			log.info("Error 정보입력 완료");
			
			log.info("Error 파일생성 완료");
		}
		
		response.setSuccessCount(cnt);
		log.info("Excel 실패 개수 : "+response.getErrorList().size());
		log.info("Excel 성공 개수 :" + cnt);
		log.info("Excel 공통 Response 생성 완료");
		return response;
	}

}
