package com.portal.common.excel;

import java.util.List;

import com.portal.common.excel.dto.ExcelGroupHeaderVO;

public interface ExcelGroupHeaderInfo{
	List<ExcelGroupHeaderVO> getGroupHeader();
	
}
