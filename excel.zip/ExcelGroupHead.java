package com.portal.common.excel;

import java.util.List;

import com.portal.common.excel.dto.ExcelGroupHeaderVO;
import com.portal.common.excel.dto.ExcelHeaderVO;

public class ExcelGroupHead implements ExcelGroupHeaderInfo,ExcelDefaultInfo{
	
	private ExcelDefaultInfo info;
	private List<ExcelGroupHeaderVO> groupHeader;
	
	public ExcelGroupHead(ExcelDefaultInfo info , List<ExcelGroupHeaderVO> groupHeader) {
		this.info = info;
		this.groupHeader = groupHeader;
	}
	
	public<T> ExcelGroupHead(ExcelErrorInfo<T> info , List<ExcelGroupHeaderVO> groupHeader) {
		this.info = info;
		this.groupHeader = groupHeader;
		
	}
	
	

	@Override
	public List<?> getData() {
		return info.getData();
	}

	@Override
	public String getSheetName() {
		return info.getSheetName();
	}

	@Override
	public List<ExcelHeaderVO> getHeader() {
		return info.getHeader();
	}

	@Override
	public String getFileName() {
		return info.getFileName();
	}


	@Override
	public List<ExcelGroupHeaderVO> getGroupHeader() {
		return this.groupHeader;
	}

}
