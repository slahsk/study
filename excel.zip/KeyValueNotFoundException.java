package com.portal.common.excel;

import lombok.Getter;

@SuppressWarnings("serial")
public class KeyValueNotFoundException extends Exception{
	@Getter
	private String fieldName;
	
	KeyValueNotFoundException(){}
	
	
	KeyValueNotFoundException(String message,String fieldName){
		super(message);
		this.fieldName = fieldName;
	}
	
	
}
