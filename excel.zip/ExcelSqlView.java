package com.portal.common.excel;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;
import org.springframework.util.ReflectionUtils;
import org.springframework.web.servlet.view.document.AbstractXlsxView;

import com.portal.common.excel.dto.ExcelHeaderVO;

@Component
public class ExcelSqlView extends AbstractXlsxView {
	public static String EXCEL_HEADER = ExcelSupport.EXCEL_HEADER;
	public static String EXCEL_DATA = ExcelSupport.EXCEL_DATA;
	public static String EXCEL_FILE_NAME = ExcelSupport.EXCEL_FILE_NAME;
	public static String EXCEL_SHHEET = ExcelSupport.EXCEL_SHHEET;
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
	@Override
	protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		 String fileName = "empty";
			try {
				fileName = URLEncoder.encode((String)model.get(EXCEL_FILE_NAME),"UTF-8").replaceAll("\\+", "%20");
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
			
		Calendar cal = Calendar.getInstance();
		fileName = fileName+"_"+sdf.format(cal.getTime());
		
		response.setHeader("Content-Disposition", "attachment; filename="+fileName+".xlsx");
		
		
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> dataList = (List<Map<String, Object>>) model.get(EXCEL_DATA);
		
		
        Sheet sheet = workbook.createSheet((String)model.get(EXCEL_SHHEET));

        // create header row
        Row header = sheet.createRow(0);
        
        int headerCellCount = 0;
        
        Map<String, Object> headerMap =  dataList.get(0);
        
        
        for(String key : headerMap.keySet()){
        	header.createCell(headerCellCount).setCellValue(key);
        	headerCellCount++;
        }
        
        
        // Create data cells
        int rowCount = 1;
        for (Map<String, Object> data : dataList){
            Row row = sheet.createRow(rowCount++);
            
            Class<?> clazz=  data.getClass();
            
            
            
            int dataCellCount = 0;
            for(String key : headerMap.keySet()){
            	 row.createCell(dataCellCount).setCellValue(String.valueOf(data.get(key)) );
            	 dataCellCount++;
            }
            
        }
		
	}
}
