package com.portal.common.excel;

public interface ExcelInfo {
	String getFileName();

}
