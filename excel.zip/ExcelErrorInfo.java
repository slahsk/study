package com.portal.common.excel;

import java.util.List;

import com.portal.common.excel.dto.ExcelError;

public interface ExcelErrorInfo<T> extends ExcelDefaultInfo,ExcelGroupHeaderInfo{

	List<ExcelError<T>> getData();
}
