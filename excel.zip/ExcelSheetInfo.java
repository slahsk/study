package com.portal.common.excel;

import java.util.List;

import com.portal.common.excel.dto.ExcelGroupHeaderVO;
import com.portal.common.excel.dto.ExcelHeaderVO;

public interface ExcelSheetInfo {
	List<ExcelHeaderVO> getHeader();
	String getSheetName();
	List<?> getData();
	
}
