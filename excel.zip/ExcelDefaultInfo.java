package com.portal.common.excel;

public interface ExcelDefaultInfo extends ExcelInfo,ExcelSheetInfo{
	
	
}
