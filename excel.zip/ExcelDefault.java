package com.portal.common.excel;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.portal.common.excel.dto.ExcelHeaderVO;

public class ExcelDefault implements ExcelDefaultInfo{
	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
	
	private final static Logger log = Logger.getLogger(ExcelDefault.class);
	
	private Map<String, Object> model;
	
	public ExcelDefault(Map<String, Object> model) {
		this.model = model;
	}
	
	
	@Override
	public String getSheetName() {
		return (String)model.get(ExcelSupport.EXCEL_SHHEET);
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<ExcelHeaderVO> getHeader() {
		return  (List<ExcelHeaderVO>) model.get(ExcelSupport.EXCEL_HEADER);
	}
	
	@Override
	public String getFileName() {
		String fileName = "empty";
		try {
			fileName = URLEncoder.encode((String)model.get(ExcelSupport.EXCEL_FILE_NAME),"UTF-8").replaceAll("\\+", "%20");
		} catch (UnsupportedEncodingException e) {
			log.error("Excel 파일 이름  encoder 실패",e);
		}
		
		Calendar cal = Calendar.getInstance();
		fileName = fileName+"_"+sdf.format(cal.getTime());
		
		return fileName;
	}
	
	@Override
	public List<?> getData() {
		return  (List<?>)model.get(ExcelSupport.EXCEL_DATA);
	}

}
