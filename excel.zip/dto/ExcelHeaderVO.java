package com.portal.common.excel.dto;

import org.apache.poi.ss.usermodel.IndexedColors;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;

@Data
public class ExcelHeaderVO {
	private String header; //Excel header
	private String property; //java property
	private IndexedColors fontColor;
	private int width;
	
	@Setter(AccessLevel.NONE)
	private String comment;
	
	
	public ExcelHeaderVO(String header, String property){
		this.header = header;
		this.property = property;
	}
	
	public ExcelHeaderVO(String header, String property, IndexedColors fontColor){
		this.header = header;
		this.property = property;
		this.fontColor = fontColor;
	}
	
	public ExcelHeaderVO(String header, String property, int width){
		this.header = header;
		this.property = property;
		this.width = width;
	}
	
	public ExcelHeaderVO(String header, String property,IndexedColors fontColor, int width){
		this.header = header;
		this.property = property;
		this.fontColor = fontColor;
		this.width = width;
	}
	
	public ExcelHeaderVO setComment(String comment){
		this.comment = comment;
		return this;
	}
	
	
}
