package com.portal.common.excel.dto;

import java.util.List;

import com.portal.common.excel.ExcelGroupHeaderInfo;
import com.portal.common.excel.ExcelSheetInfo;

public class ExcelSheetVO implements ExcelSheetInfo,ExcelGroupHeaderInfo{

	private List<?> data;
	private String sheetName;
	private List<ExcelHeaderVO> header;
	private List<ExcelGroupHeaderVO> group;
	
	public ExcelSheetVO(List<?> data,List<ExcelHeaderVO> header, String sheetName){
		this.data = data;
		this.header = header;
		this.sheetName = sheetName;
	}
	
	public ExcelSheetVO(List<?> data,List<ExcelHeaderVO> header,List<ExcelGroupHeaderVO> group, String sheetName){
		this.data = data;
		this.header = header;
		this.group = group;
		this.sheetName = sheetName;
	}
	
	@Override
	public String getSheetName() {
		return sheetName;
	}

	@Override
	public List<?> getData() {
		return data;
	}

	@Override
	public List<ExcelHeaderVO> getHeader() {
		return header;
	}


	@Override
	public List<ExcelGroupHeaderVO> getGroupHeader() {
		return group;
	}


}
