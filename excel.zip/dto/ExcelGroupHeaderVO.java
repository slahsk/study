package com.portal.common.excel.dto;

import org.apache.poi.ss.util.CellRangeAddress;

import lombok.Data;

@Data
public class ExcelGroupHeaderVO {
	private String titleText;
	private CellRangeAddress cellRangeAddress;
	private short fontColor;
	
	public ExcelGroupHeaderVO(CellRangeAddress cellRangeAddress,String titleText){
		this.cellRangeAddress = cellRangeAddress;
		this.titleText = titleText;
	}
	
	public ExcelGroupHeaderVO(CellRangeAddress cellRangeAddress,String titleText,short fontColor){
		this.cellRangeAddress = cellRangeAddress;
		this.titleText = titleText;
		this.fontColor = fontColor;
	}
}
