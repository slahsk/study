package com.portal.common.excel.dto;

import java.util.HashMap;
import java.util.Map;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ExcelError<T>{
//	private String meesage;
	private Map<String, String> errorField = new HashMap<>();
	private T data;
	private ExcepErrorType excepErrorType;
	
//	public ExcelError(T data,String message){
//		this.data = data;
//		this.meesage = message;
//	}
	
	
	
	public void setErrorField(String field, String message){
		errorField.put(field, message);
	}
}
