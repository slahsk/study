package com.portal.common.excel.dto;

public enum ExcepErrorType {
	EXCEL_TO_VO,VO_TO_DB
}
