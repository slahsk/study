package com.portal.common.excel.dto;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.StringUtils;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class ExcelResponseVO <T> {
	
	@Getter(AccessLevel.NONE)
	private int successCount;
	
	private int totalCount;
	
	/**
	 * 업로드한 파일 이름 
	 */
	private String fileName;
	
	/**
	 *에러 발생시 DB에 정보 저장시 구분되는 코드 
	 */
	@Setter(AccessLevel.NONE)
	private String taskItemEventCd;
	
	@Setter(AccessLevel.NONE)
	private String actvTaskCd;
	
	@Setter(AccessLevel.NONE)
	private String actvItemCd;
	
	@Setter(AccessLevel.NONE)
	private String actvEventCd;
	
	/**
	 * 에러 발생시 만들어지는 엑셀 헤더  
	 */
	private List<ExcelHeaderVO> header =  new ArrayList<>();
	
	
	private List<ExcelGroupHeaderVO> groupHeader = new ArrayList<>();
	
	/**
	 * 에러 발생시 가지고 있는 vo 정보
	 */
	private List<ExcelError<T>> errorList  = new ArrayList<>();
	
	/**
	 * 엑셀을 파싱하여 VO객체로 성공적으로 변화 되어 저장 있는 리스트
	 */
	private List<T> excelToVOList = new ArrayList<>();
	
//	public void addError(T data, String message){
//		errorList.add(new ExcelError<T>(data, message));
//	}
	
	/**
	 * Description : VO 객체를 DB저장시 에러 날면 사용하는 메소드
	 * 
	 * @param data
	 * @param field
	 * @param message
	 */
	public void addError(T data,String field , String message){
		ExcelError<T> error = new ExcelError<T>();
		error.setData(data);
		error.setErrorField(field, message);
		error.setExcepErrorType(ExcepErrorType.VO_TO_DB);
		errorList.add(error);
	}
	
	
	public void addError(ExcelError<T> error){
		errorList.add(error);
	}
	
	public void addExcelToVO(T vo){
		excelToVOList.add(vo);
	}
	
	public int getSuccessCount(){
		return totalCount - errorList.size();
	}
	
	public void setTaskItemEventCd(String taskItemEventCd){
		this.taskItemEventCd = taskItemEventCd;
		
		if (!StringUtils.isEmpty(taskItemEventCd)) {
			String[] keyArr = taskItemEventCd.split("\\-");
			this.actvTaskCd = keyArr[0];
			this.actvItemCd = keyArr[1];
			this.actvEventCd = keyArr[2];
		}
	}
}


