package com.portal.common.excel;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ReflectionUtils;
import org.springframework.web.multipart.MultipartFile;

import com.portal.common.excel.dto.ExcelError;
import com.portal.common.excel.dto.ExcelGroupHeaderVO;
import com.portal.common.excel.dto.ExcelHeaderVO;
import com.portal.common.excel.dto.ExcelResponseVO;
import com.portal.common.excel.dto.ExcepErrorType;

@Component
public class ExcelHeaderMapping {
	
	
	private final static Logger log = Logger.getLogger(ExcelHeaderMapping.class);
	
	/**
	 * 예외 되는 변수들
	 */
	private static Set<String> excludeField = new HashSet<>(
			Arrays.asList("serialVersionUID", "this$0")
			);
	

	/**
	 * Description : target 객체에 value 객체의 값을 넣어준다.
	 * 
	 * @param target : 값을 넣을 대상이 되는 객체
	 * @param value : 값을 가져오는 객체
	 * @return
	 * @throws KeyValueNotFoundException
	 */
	public <T> T mergeValue(T target, T value) throws KeyValueNotFoundException{
		
			@SuppressWarnings("unchecked")
			Class<T> clazz = (Class<T>) target.getClass();
			List<Field> feildList = FieldUtils.getAllFieldsList(clazz);
			for (Field field : feildList){
				if (!excludeField.contains(field.getName())) {
					ReflectionUtils.makeAccessible(field);
					Object val;
					try {
						val =FieldUtils.readField(field,value);
						
						if(field.isAnnotationPresent(ExcelKey.class) && val == null){
							throw new KeyValueNotFoundException("Key("+field.getName()+") 변수에 값이 없습니다",field.getName());
						}
						
						if(val != null){
							FieldUtils.writeField(field, target, val);
						}
						
					} catch (IllegalArgumentException | IllegalAccessException e) {
						e.printStackTrace();
					}
				}
			}
		
		return target;
	}
	
	
	/**
	 * Description : 입력 받은 엑셀 파일은 vo 객체로 변경
	 * 
	 * @Deprecated : ExcelResponseVO 생성해서 사용하도록 권장함
	 * 
	 * 
	 * 
	 * @param multi : 화면에서 오는 파일 객체
	 * @param mappingList : 엑셀 헤더 검사할 리스트
	 * @param clazz :  변화 대상 클레스
	 * @return
	 */
	@Deprecated
	public <T> List<T> getExistValueList(MultipartFile multi, List<ExcelHeaderVO> mappingList, Class<T> clazz) {
		
		Workbook wb = null;
		try {
			wb = WorkbookFactory.create(multi.getInputStream());
		} catch (EncryptedDocumentException | InvalidFormatException | IOException e) {
			e.printStackTrace();
		}
		return getExistValueList(wb, mappingList, clazz);
	}
	
	/**
	 * Description : 
	 * 
	 * @param file: 화면에서 오는 파일 객체
	 * @param mappingList : 엑셀 헤더 검사할 리스트
	 * @param clazz :  변화 대상 클레스
	 * @return
	 */
	public <T> ExcelResponseVO<T> getExistValueReponse(File file, List<ExcelHeaderVO> mappingList, Class<T> clazz) {
		Workbook wb = null;
		try {
			wb = WorkbookFactory.create(file);
		} catch (EncryptedDocumentException | InvalidFormatException | IOException e) {
			e.printStackTrace();
		}
		
		return getExistValueReponse(wb, mappingList, clazz,null);
	}
	
	/**
	 * Description : 
	 * 
	 * @param multi: 화면에서 오는 파일 객체
	 * @param mappingList : 엑셀 헤더 검사할 리스트
	 * @param clazz :  변화 대상 클레스
	 * @return
	 */
	public <T> ExcelResponseVO<T> getExistValueReponse(MultipartFile multi, List<ExcelHeaderVO> mappingList, Class<T> clazz){
		
		Workbook wb = null;
		try {
			wb = WorkbookFactory.create(multi.getInputStream());
		} catch (EncryptedDocumentException | InvalidFormatException | IOException e) {
			e.printStackTrace();
		}
		return getExistValueReponse(wb, mappingList, clazz,null);		
	}
	
	public <T> ExcelResponseVO<T> getExistValueReponse(MultipartFile multi, List<ExcelHeaderVO> mappingList, Class<T> clazz, List<ExcelGroupHeaderVO> groupHeaderList){
		
		Workbook wb = null;
		try {
			wb = WorkbookFactory.create(multi.getInputStream());
		} catch (EncryptedDocumentException | InvalidFormatException | IOException e) {
			e.printStackTrace();
		}
		return getExistValueReponse(wb, mappingList, clazz, groupHeaderList );		
	}
	
	
	/**
	 * Description : 엑셀 헤더 에 있는 값만 검사하여 VO 객체를 생성하여 값을 맵핑 한다
	 * 
	 * @param wb : POI 엑셀 객체
	 * @param mappingList : 엑셀 헤더 검사할 리스트
	 * @param clazz : 변화 대상 클레스
	 * @return
	 */
	public <T> ExcelResponseVO<T> getExistValueReponse(Workbook wb, List<ExcelHeaderVO> mappingList, Class<T> clazz, List<ExcelGroupHeaderVO> groupHeaderList) {

		Sheet sheet = wb.getSheetAt(0);
		
		int dataRowCount = sheet.getLastRowNum();
		Row header = null;
		if(Objects.nonNull(groupHeaderList)){
			log.info("그룹 헤더 생성");
			int lastRow = 0;
			for(ExcelGroupHeaderVO group : groupHeaderList){
				if(lastRow < group.getCellRangeAddress().getLastRow()){
					lastRow = group.getCellRangeAddress().getLastRow();
				}
			}
			
			for(int i = 0 ; i <= lastRow; i++){
				sheet.removeRow(sheet.getRow(i));
			}
			header = sheet.getRow(lastRow + 1);
			dataRowCount = dataRowCount - (lastRow +1);
			
			log.info("그룹 헤더 마지막 ROW:" + lastRow);
			log.info("그룹 헤더 생성 완료");
		}else{
			
			//엑셀 헤더 필드 이름 목록
			header = sheet.getRow(0);
		}
		
		List<ExcelHeaderVO> existList = existProperty(header, mappingList);
		
		sheet.removeRow(header);		
		//헤더 row 삭제
		
		
		log.info("엑셀데이터 VO 변경 시작");
		ExcelResponseVO<T> reponse = new ExcelResponseVO<T>();
		reponse.setTotalCount(dataRowCount);
		
		try {
			for (Row row : sheet) {
				T obj = clazz.newInstance();
				ExcelError<T> error = null;
				for (Cell cell : row) {
					try{
						Field field = ReflectionUtils.findField(clazz, existList.get(cell.getColumnIndex()).getProperty());
						ReflectionUtils.makeAccessible(field);
						String val = getCellValue(cell);
						
						
					
						if(Objects.nonNull(val) && !"".equals(String.valueOf(val).trim())){
							
							if(field.getType().equals(Integer.class)){
								ReflectionUtils.setField(field, obj, Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(val)))));
							}else if(field.getType().equals(Float.class)){
								ReflectionUtils.setField(field, obj, Float.parseFloat(val));
							}else if(field.getType().equals(Long.class)){
								ReflectionUtils.setField(field, obj, Long.parseLong(val));
							}else if(field.getType().equals(Double.class)){
								ReflectionUtils.setField(field, obj, Double.parseDouble(val));
							}else{
								ReflectionUtils.setField(field, obj, val);
							}
						}
						
						
					}catch (Exception e) {
						if(Objects.isNull(error)){
							error = new ExcelError<T>();
						}
						error.setErrorField(existList.get(cell.getColumnIndex()).getHeader(), e.toString());
						log.error("엑셀 CELL 처리중 에러",e);
					}
				} //for
				
				if(Objects.nonNull(error)){
					error.setData(obj);
					error.setExcepErrorType(ExcepErrorType.EXCEL_TO_VO);
					reponse.addError(error);
					error = null;
				}else{
					reponse.addExcelToVO(obj);
				}
				
			}
		} catch (InstantiationException | IllegalAccessException e) {
			log.error("vo 생성을 못했습니다.",e);
		}
		reponse.setHeader(existList);
		
		
		if(Objects.nonNull(groupHeaderList)){
			reponse.setGroupHeader(groupHeaderList);
		}
		log.info("변경 된 VO 개수 :" +reponse.getExcelToVOList().size());
		log.info("변경 실패한 VO 개수 :" + reponse.getErrorList().size());
		log.info("데이터 개수 : " + reponse.getTotalCount() );
		log.info("엑셀데이터 VO 변경 완료");
		return reponse;
	}
	
	
	/**
	 * Description : 엑셀 파일을 vo 객체로 변경
	 * 
	 * @param file 
	 * @param mappingList : 엑셀 헤더 검사할 리스트
	 * @param clazz : 변화 대상 클레스
	 * @return
	 */
	public <T> List<T> getExistValueList(File file, List<ExcelHeaderVO> mappingList, Class<T> clazz) {
		Workbook wb = null;
		try {
			wb = WorkbookFactory.create(file);
		} catch (EncryptedDocumentException | InvalidFormatException | IOException e) {
			e.printStackTrace();
		}
		
		return getExistValueList(wb, mappingList, clazz);
	}
	
	
	/**
	 * Description : 엑셀파일은 vo객체로 변경
	 * 
	 * @param wb : POI 엑셀 객체
	 * @param mappingList : 엑셀 헤더 검사할 리스트
	 * @param clazz : 변화 대상 클레스
	 * @return
	 */
	@Deprecated
	public <T> List<T> getExistValueList(Workbook wb, List<ExcelHeaderVO> mappingList, Class<T> clazz) {

		Sheet sheet = wb.getSheetAt(0);
		Row header = sheet.getRow(0);

		List<ExcelHeaderVO> existList = existProperty(header, mappingList);
		sheet.removeRow(header);
		
		
		List<T> result = new ArrayList<>();
		try {
			for (Row row : sheet) {
				T obj = clazz.newInstance();
				for (Cell cell : row) {
					Field field = ReflectionUtils.findField(clazz, existList.get(cell.getColumnIndex()).getProperty());
					ReflectionUtils.makeAccessible(field);
					String val = getCellValue(cell);
					
					if(field.getType().equals(Integer.class) && !val.equals("")){
						ReflectionUtils.setField(field, obj, Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(val)))));
					}else if(!val.equals("")){
						ReflectionUtils.setField(field, obj, val);
					}
					
				}
				result.add(obj);
			}
		} catch (InstantiationException | IllegalAccessException e) {
			e.printStackTrace();
		}

		return result;
	}

	/**
	 * Description : 엑셀파일 가장 위 헤더 부분의 값(한글) 을 가져와서 자바 속성명 을 매치 하여
	 * 리스트는 리턴
	 * 
	 * @param header : excel row 객체
	 * @param mappingList : 엑셀 헤더 검사할 리스트
	 * @return
	 */
	private List<ExcelHeaderVO> existProperty(Row header, List<ExcelHeaderVO> mappingList) {
		List<ExcelHeaderVO> existList = new ArrayList<>();

		for (Cell cell : header) {

			for (ExcelHeaderVO headerVO : mappingList) {
				if (headerVO.getHeader().equals(cell.getStringCellValue())) {
					existList.add(headerVO);
				}
			}
		}

		return existList;
	}
	
	/**
	 * Description : 엑셀파일 값 읽어 올때 타입에 맞게 값 읽어 오기
	 * 
	 * @param cell
	 * @return
	 */
	private String getCellValue(Cell cell) {
	    if (cell == null){
	    	return "";
	    }
	    

	    switch (cell.getCellType()) {
		    case Cell.CELL_TYPE_STRING:
		        return cell.getStringCellValue().trim();
		    case Cell.CELL_TYPE_NUMERIC:
		        BigDecimal dphi = new BigDecimal(Math.round(cell.getNumericCellValue()));
		        return String.valueOf(dphi);
		    case Cell.CELL_TYPE_BOOLEAN:
		        return Boolean.toString(cell.getBooleanCellValue());
		    case Cell.CELL_TYPE_FORMULA:
		        return cell.getStringCellValue();
		    case Cell.CELL_TYPE_ERROR:
		    	return null;

	    }
	    return "";
	}
	 

}
