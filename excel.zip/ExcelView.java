package com.portal.common.excel;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.view.document.AbstractXlsxView;

import com.portal.common.excel.dto.ExcelGroupHeaderVO;
import com.portal.common.excel.dto.ExcelSheetVO;

@Component
public class ExcelView extends AbstractXlsxView {
	private final static Logger log = Logger.getLogger(ExcelView.class);
	
	@Autowired
	private ExcelSupport excelSupport;
	
	
	public static String EXCEL_HEADER = ExcelSupport.EXCEL_HEADER;
	public static String EXCEL_DATA = ExcelSupport.EXCEL_DATA;
	public static String EXCEL_FILE_NAME = ExcelSupport.EXCEL_FILE_NAME;
	public static String EXCEL_SHHEET = ExcelSupport.EXCEL_SHHEET;
	
	
	@Override
	protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		@SuppressWarnings("unchecked")
		List<ExcelSheetVO> dataList = (List<ExcelSheetVO>) model.get(ExcelSupport.EXCEL_DATA_LIST);
		
		String fileName="";
		if(Objects.nonNull(dataList)){
			for(ExcelSheetVO data : dataList){
				Map<String, Object> map = new HashMap<>();
				map.put(ExcelSupport.EXCEL_SHHEET, data.getSheetName());
				map.put(ExcelSupport.EXCEL_DATA, data.getData());
				map.put(ExcelSupport.EXCEL_HEADER, data.getHeader());
				map.put(ExcelSupport.EXCEL_FILE_NAME, model.get(ExcelSupport.EXCEL_FILE_NAME));
				
				
				if(Objects.nonNull(data.getGroupHeader())){
					map.put(ExcelSupport.EXCEL_GROUP, data.getGroupHeader());
				}
				
				ExcelDefaultInfo info = ExcelCreate(map, workbook);
				fileName = info.getFileName();
			}
			
			
		}else{
			ExcelDefaultInfo info = ExcelCreate(model, workbook);
			fileName = info.getFileName();
		}
		
		response.setHeader("Content-Disposition", "attachment; filename="+fileName+".xlsx");
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		
	}


	private ExcelDefaultInfo ExcelCreate(Map<String, Object> map, Workbook workbook) {
		ExcelDefaultInfo info = new ExcelDefault(map);
		
		
		if(Objects.isNull(map.get(ExcelSupport.EXCEL_GROUP))){
			excelSupport.create(workbook, info);
		}else{
			@SuppressWarnings("unchecked")
			ExcelGroupHead groupInfo = new ExcelGroupHead(info,(List<ExcelGroupHeaderVO>) map.get(ExcelSupport.EXCEL_GROUP));
			excelSupport.create(workbook, groupInfo);
		}
		return info;
	}
}
